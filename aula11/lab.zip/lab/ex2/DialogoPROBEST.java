package aula11.lab.ex2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DialogoPROBEST extends JDialog implements ActionListener {
    JLabel lb;
    JTextField tf;
    JButton bt;
    int tam;
    int vet[];

    public DialogoPROBEST(JFrame fr) {
        super(fr, true);
        Container cp = getContentPane();
        cp.setLayout(new FlowLayout());
        lb = new JLabel("Selecione uma opção no menu!");
        cp.add(lb);
        tf = new JTextField(10);
        cp.add(tf);
        bt = new JButton("OK");
        cp.add(bt);
        bt.addActionListener(this);
        JMenu menu = new JMenu("Opções");
        menu.setMnemonic('O');
        menu.addSeparator();
        JMenuItem media = new JMenuItem("Média");
        media.setMnemonic('X');
        media.addActionListener(this);
        JMenuItem desvpad = new JMenuItem("Desvio padrão");
        desvpad.setMnemonic('I');
        desvpad.addActionListener(this);
        JMenuItem variancia = new JMenuItem("Variancia");
        variancia.setMnemonic('A');
        variancia.addActionListener(this);
        JMenuItem mediana = new JMenuItem("Mediana");
        mediana.setMnemonic('A');
        mediana.addActionListener(this);
        JMenuItem coef_assi = new JMenuItem("Coeficiente de assimetria");
        coef_assi.setMnemonic('A');
        coef_assi.addActionListener(this);
        JMenuItem coef_var = new JMenuItem("Coeficiente de variação");
        coef_assi.setMnemonic('A');
        coef_assi.addActionListener(this);
        JMenuBar barra = new JMenuBar();
        setJMenuBar(barra);
        barra.add(menu);
        menu.add(media);
        menu.add(desvpad);
        menu.add(variancia);
        menu.add(mediana);
        menu.add(coef_assi);
        menu.add(coef_var);
        setSize(200, 150);
        setLocation(200, 200);
        setTitle("Vetor");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bt.setVisible(false);
        tf.setVisible(false);
        setVisible(true);

        if (fr.isVisible() == false)
            System.exit(0);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("media")) {
            tf.setVisible(true);
            bt.setVisible(true);
            tam = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor: "));
            vet = new int[tam];
            tf.setVisible(false);
            bt.setVisible(false);
            lb.setText("Vetor mediado!");
        }
        if (e.getActionCommand().equals("desvpad")) {
            tf.setVisible(true);
            bt.setVisible(true);
            for (int i = 0; i < vet.length; i++) {
                vet[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor da posição " + i + ": "));
            }
            tf.setVisible(false);
            bt.setVisible(false);
            lb.setText("Vetor preenchido!");
        }
        if (e.getActionCommand().equals("variancia")) {
            tf.setVisible(false);
            bt.setVisible(false);
            String s = "";
            for (int i = 0; i < vet.length; i++) {
                s += vet[i] + " ";
            }
            lb.setText("Vetor: " + s);
        }
        if (e.getSource() == bt) {
            dispose();
        }

    }
}
