package aula11.lab.ex1;

import javax.swing.JDialog;
import javax.swing.JFrame;

public class DialogoVetorTeste {
    public static void main(String[] args) {
        JFrame fr = new JFrame();
        Dialogo dialogo = new Dialogo(fr);
    }
    
}
