

public class TesteTelaLogin {
    
        public static void main(String[] args) {
            TelaLogin tela = new TelaLogin();
            tela.setVisible(true);
        }
    
}
